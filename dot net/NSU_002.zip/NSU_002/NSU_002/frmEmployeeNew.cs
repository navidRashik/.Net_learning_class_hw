﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace NSU_002
{
    public partial class frmEmployeeNew : Form
    {
        public frmEmployeeNew()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmEmployeeNew_Load(object sender, EventArgs e)
        {
            SqlConnection CN = new SqlConnection("Data Source=.;Initial Catalog=dbNSU001;Integrated Security=True");
            CN.Open();


            SqlCommand CMD = new SqlCommand();
            CMD.CommandText = "select id, name from city order by name  asc";
            CMD.Connection = CN;

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(CMD);

            da.Fill(ds);

            cmbCity.DataSource = ds.Tables[0];
            cmbCity.DisplayMember = "name";
            cmbCity.ValueMember = "id";

            cmbCity.SelectedValue = -1;

        }

        private void frmEmployeeNew_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int er = 0;
            string msg = "";

            if(txtName.Text == "")
            {
                er++;
                msg += "Name Required\n";
            }

            if (txtContact.Text == "")
            {
                er++;
                 msg += "Contact Required\n";
            }

            if (txtEmail.Text == "")
            {
                er++;
                msg += "Email Required\n";
            }

            if (cmbCity.SelectedValue == null)
            {
                er++;
                msg += "Select City\n";
            }

            if(er == 0)
            {
                SqlConnection CN = new SqlConnection("Data Source=.;Initial Catalog=dbNSU001;Integrated Security=True");
                CN.Open();


                SqlCommand CMD = new SqlCommand();
                CMD.CommandText = "insert into students(name, contact, email, address, cityId) values('"+txtName.Text+"', '"+txtContact.Text+"', '"+txtEmail.Text+"', '"+txtAddress.Text+"', "+cmbCity.SelectedValue.ToString()+")";
                CMD.Connection = CN;

                try
                {
                    CMD.ExecuteNonQuery();

                    MessageBox.Show("Data Saved");
                    txtName.Text = "";
                    txtEmail.Text = "";
                    txtContact.Text = "";
                    txtAddress.Text = "";
                    cmbCity.SelectedValue = -1;
                    txtName.Focus();
                }
                catch(Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }


            }
            else
            {
                MessageBox.Show(msg);
            }

        }
    }
}
