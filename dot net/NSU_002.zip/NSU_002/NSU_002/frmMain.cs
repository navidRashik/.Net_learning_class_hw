﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NSU_002
{
    public partial class frmMain : Form
    {

        frmCity city = new frmCity();
        frmEmployee emp = new frmEmployee();
        NSU_002.Preasentation.frmUnit unit = new Preasentation.frmUnit();
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.MinimumSize = this.Size;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString();
        }

        private void cityToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if(city.IsDisposed)
                city = new frmCity();
           
            city.MdiParent = this;
            city.Show();
            city.BringToFront();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (emp.IsDisposed)
                emp = new frmEmployee();
            emp.MdiParent = this;
            emp.Show();
            emp.BringToFront();
        }

        private void unitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (unit.IsDisposed)
                unit = new Preasentation.frmUnit();
            unit.MdiParent = this;
            unit.Show();
            unit.BringToFront();
        }
    }
}
