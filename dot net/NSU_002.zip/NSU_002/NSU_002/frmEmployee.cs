﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace NSU_002
{
    public partial class frmEmployee : Form
    {
        public frmEmployee()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection CN = new SqlConnection("Data Source=.;Initial Catalog=dbNSU001;Integrated Security=True");
            CN.Open();


            SqlCommand CMD = new SqlCommand();
            CMD.CommandText = @"select s.id, s.name, s.contact, s.email, s.address, ct.name as city 
                                    from students as s left join city as ct on s.cityId = ct.id  where s.id > 0 ";


            if(txtSearch.Text != "")
            {
                CMD.CommandText += " and (s.name like '%" + txtSearch.Text + "%' or s.email like '%" + txtSearch.Text + "%' or s.contact like '%" + txtSearch.Text + "%')";
            }

            if(cmbCity.SelectedValue != null)
            {
                CMD.CommandText += " and ct.id = " + cmbCity.SelectedValue.ToString();
            }

            CMD.CommandText += " order by s.name asc";

            CMD.Connection = CN;

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(CMD);

            da.Fill(ds);

            dgvData.DataSource = ds.Tables[0];

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            frmEmployeeNew empN = new frmEmployeeNew();
            empN.ShowDialog();
        }

        private void frmEmployee_Load(object sender, EventArgs e)
        {
            SqlConnection CN = new SqlConnection("Data Source=.;Initial Catalog=dbNSU001;Integrated Security=True");
            CN.Open();


            SqlCommand CMD = new SqlCommand();
            CMD.CommandText = "select id, name from city order by name  asc";
            CMD.Connection = CN;

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(CMD);

            da.Fill(ds);

            cmbCity.DataSource = ds.Tables[0];
            cmbCity.DisplayMember = "name";
            cmbCity.ValueMember = "id";

            cmbCity.SelectedValue = -1;

        }
    }
}
