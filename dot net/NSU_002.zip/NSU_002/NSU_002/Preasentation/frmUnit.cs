﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace NSU_002.Preasentation
{
    public partial class frmUnit : Form
    {
        public frmUnit()
        {
            InitializeComponent();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            frmUnitNew unitNew = new frmUnitNew();
            unitNew.ShowDialog();

            button5.PerformClick();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(NSU_002.Properties.Settings.Default.CN);
            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select id, name, description from unit";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            dgvData.DataSource = ds.Tables[0];

        }
    }
}
