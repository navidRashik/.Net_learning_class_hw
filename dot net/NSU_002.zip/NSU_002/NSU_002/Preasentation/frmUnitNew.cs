﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace NSU_002.Preasentation
{
    public partial class frmUnitNew : Form
    {

        ErrorProvider ep = new ErrorProvider();
        public frmUnitNew()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int er = 0;
            ep.Clear();

            if(txtName.Text == "")
            {
                er++;
                ep.SetError(txtName, "Required Field");
            }

            if (er == 0)
            {
                SqlConnection cn = new SqlConnection(NSU_002.Properties.Settings.Default.CN);
                cn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandText = "insert into unit(name, description) values(@name, @description)";

                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@description", txtDescription.Text);


                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Unit Inserted Successfully");
                    txtName.Text = "";
                    txtDescription.Text = "";
                    txtName.Focus();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                cn.Close();

            }

        }
    }
}
