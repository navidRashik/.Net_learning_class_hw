﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace customer_relationship_management
{
    public partial class Form1 : Form
    {
        frmCustomer fp = new frmCustomer();
        frmEmployee fc = new frmEmployee();
        frmProducts fk = new frmProducts();
        frmTransaction ft = new frmTransaction();
        frmCountry frc = new frmCountry();
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.MinimumSize = this.Size;
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripContainer1_TopToolStripPanel_Click(object sender, EventArgs e)
        {

        }

        private void profileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fp.IsDisposed)
                fp = new frmCustomer();
            fp.Show();
            fp.MdiParent = this;
        }

        private void countryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frc.IsDisposed)
                frc = new frmCountry();
            frc.Show();
            frc.MdiParent = this;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fc.IsDisposed)
                fc = new frmEmployee();
            fc.Show();
            fc.MdiParent = this;
        }

        private void unitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNewUnit fu = new frmNewUnit();
            if (fu.IsDisposed)
                fu = new frmNewUnit();
            fu.Show();
            fu.MdiParent = this;
        }

        private void productToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (fk.IsDisposed)
                fk = new frmProducts();
            fk.Show();
            fk.MdiParent = this;
        }

        private void transationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ft.IsDisposed)
                ft = new frmTransaction();
            ft.Show();
            ft.MdiParent = this;
        }

        private void cityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCity fct = new frmCity();
            if (fct.IsDisposed)
                fct = new frmCity();
            fct.Show();
            fct.MdiParent = this;
        }

        private void catagoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNewCatagory fu = new frmNewCatagory();
            if (fu.IsDisposed)
                fu = new frmNewCatagory();
            fu.Show();
            fu.MdiParent = this;
        }
    }
}
