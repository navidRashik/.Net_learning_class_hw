﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSU_PRO1.DAL
{
    class PersonIntrest : Baseses.MyBase
    {
        public int personId { get; set; }
        public int IntrestId { get; set; }

        public bool Insert()
        {
            MyCommand = MyCommandBuilder(@"insert into personinterest(personid,intrestid)
                                                valus(@personid,@intrestid");
            MyCommand.Parameters.AddWithValue("@personid", personId);
            MyCommand.Parameters.AddWithValue("@intrestid", IntrestId);

            return ExecuteNonQuery(MyCommand);
        }

        public bool Update()
        {
            MyCommand = MyCommandBuilder(@"update personinterest set intrestid = @intrestid
                                            where personid = @personid");
            MyCommand.Parameters.AddWithValue("@personid", personId);
            MyCommand.Parameters.AddWithValue("@intrestid", IntrestId);

            return ExecuteNonQuery(MyCommand);
        }

        public bool Delete()
        {
            MyCommand = MyCommandBuilder(@"delete from personinterest
                                            where personid = @personid");
            MyCommand.Parameters.AddWithValue("@personid", personId);

            return ExecuteNonQuery(MyCommand);
        }



        public bool SelectById()
        {
            MyCommand = MyCommandBuilder("select personid, intrestid from personinterest where personid = @personid ");
            MyCommand.Parameters.AddWithValue("@personid", personId);

            MyReader = MyCommand.ExecuteReader();

            while (MyReader.Read())
            {
                IntrestId = Convert.ToInt32(MyReader["intrestid"]);
                return true;
            }
            return false;
        }

        public System.Data.DataSet select()
        {
            MyCommand = MyCommandBuilder(@"select personid,intrestid from personinterest");
            return ExecuteDataSet(MyCommand);
        }

    }
}
