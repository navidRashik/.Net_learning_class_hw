﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSU_PRO1.DAL
{
    class PersonEducation:Baseses.MyBase
    {

        public int Id { get; set; }
        public int PersonId { get; set; }
        public int EducationId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime CompleteDate { get; set; }
        public int InstituteId { get; set; }

        public string Result { get; set; }

        public string Remarks { get; set; }

        public bool Insert()
        {
            MyCommand = MyCommandBuilder(@"insert into PersonEducation(PersonId, EducationId, StartDate, 
                CompleteDate, InstituteId, Result, Remarks) values(@PersonId, @EducationId, 
                @StartDate, @CompleteDate, @InstituteId, @Result, @Remarks)");

            MyCommand.Parameters.AddWithValue("@PersonId", PersonId);
            MyCommand.Parameters.AddWithValue("@EducationId", EducationId);
            MyCommand.Parameters.AddWithValue("@StartDate", StartDate);
            MyCommand.Parameters.AddWithValue("@CompleteDate", CompleteDate);
            MyCommand.Parameters.AddWithValue("@InstituteId", InstituteId);
            MyCommand.Parameters.AddWithValue("@Result", Result);
            MyCommand.Parameters.AddWithValue("@Remarks", Remarks);

            return ExecuteNonQuery(MyCommand);
        }

        public bool Update()
        {
            MyCommand = MyCommandBuilder("update PersonEducation set PersonId = @PersonId, EducationId = @EducationId, StartDate = @StartDate, CompleteDate = @CompleteDate, InstituteId = @InstituteID, Result = @Result, Remarks = @Remarks where id = @id");

            MyCommand.Parameters.AddWithValue("@id", Id);
            MyCommand.Parameters.AddWithValue("@PersonId", PersonId);
            MyCommand.Parameters.AddWithValue("@EducationId", EducationId);
            MyCommand.Parameters.AddWithValue("@StartDate", StartDate);
            MyCommand.Parameters.AddWithValue("@CompleteDate", CompleteDate);
            MyCommand.Parameters.AddWithValue("@InstituteId", InstituteId);
            MyCommand.Parameters.AddWithValue("@Result", Result);
            MyCommand.Parameters.AddWithValue("@Remarks", Remarks);

            return ExecuteNonQuery(MyCommand);
        }

        public bool Delete()
        {
            MyCommand = MyCommandBuilder("delete from PersonEducation where id = @id");

            MyCommand.Parameters.AddWithValue("@id", Id);

            return ExecuteNonQuery(MyCommand);
        }

        public bool SelectById()
        {
            MyCommand = MyCommandBuilder("select id, PersonId, EducationId, StartDate, CompleteDate, InstituteId, Result, Remarks from PersonEducation where id = @id");

            MyCommand.Parameters.AddWithValue("@id", Id);


            MyReader = MyCommand.ExecuteReader();

            while(MyReader.Read())
            {
                PersonId = Convert.ToInt32( MyReader["PersonId"]);
                EducationId = Convert.ToInt32(MyReader["EducationId"]);
                StartDate = Convert.ToDateTime(MyReader["StartDate"]);
                CompleteDate = Convert.ToDateTime (MyReader["CompleteDate"]);
                InstituteId = Convert.ToInt32(MyReader["InstituteId"]);
                 Result = MyReader["Result"].ToString();
                 Remarks = MyReader["Remarks"].ToString();
                return true;
            }
            return false;
        }

        public System.Data.DataSet Select()
        {
            MyCommand = MyCommandBuilder("Select id, PersonId, EducationId, StartDate, CompleteDate, InstituteId, Result, Remarks from PersonEducation");
            return ExecuteDataSet(MyCommand);
        }


    }
}
