﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSU_PRO1.DAL
{
    class PersonEmail : Baseses.MyBase
    {
        public int personId { get; set; }
        public string email { get; set; }

        public bool Insert()
        {
            MyCommand = MyCommandBuilder(@"insert into personemail(personid,email)
                                                valus(@personid,@email");
            MyCommand.Parameters.AddWithValue("@personid", personId);
            MyCommand.Parameters.AddWithValue("@email", email);

            return ExecuteNonQuery(MyCommand);
        }

        public bool Update()
        {
            MyCommand = MyCommandBuilder(@"update personemail set email = @email
                                            where personid = @personid");
            MyCommand.Parameters.AddWithValue("@personid", personId);
            MyCommand.Parameters.AddWithValue("@email", email);

            return ExecuteNonQuery(MyCommand);
        }

        public bool Delete()
        {
            MyCommand = MyCommandBuilder(@"delete from personemail
                                            where personid = @personid");
            MyCommand.Parameters.AddWithValue("@personid", personId);
           
            return ExecuteNonQuery(MyCommand);
        }

       

        public bool SelectById()
        {
            MyCommand = MyCommandBuilder("select personid, email from personemail where personid = @personid ");
            MyCommand.Parameters.AddWithValue("@personid", personId);

            MyReader = MyCommand.ExecuteReader();

            while (MyReader.Read())
            {
                email = MyReader["email"].ToString();
                return true;
            }
            return false;
        }

        public System.Data.DataSet select()
        {
            MyCommand = MyCommandBuilder(@"select personid,email from personemail");
            return ExecuteDataSet(MyCommand);
        }
    }
}
