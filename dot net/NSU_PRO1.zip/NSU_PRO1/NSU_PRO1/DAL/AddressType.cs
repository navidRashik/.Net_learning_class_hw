﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSU_PRO1.DAL
{
    class AddressType:Baseses.MyBase
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public bool Insert()
        {
            MyCommand = MyCommandBuilder("insert into AddressType(name, description) values(@name, @description)");

            MyCommand.Parameters.AddWithValue("@name", Name);
            MyCommand.Parameters.AddWithValue("@description", Description);

            return ExecuteNonQuery(MyCommand);
        }

        public bool Update()
        {
            MyCommand = MyCommandBuilder("update AddressType set name = @name, description =  @description where id = @id");

            MyCommand.Parameters.AddWithValue("@id", Id);
            MyCommand.Parameters.AddWithValue("@name", Name);
            MyCommand.Parameters.AddWithValue("@description", Description);

            return ExecuteNonQuery(MyCommand);
        }

        public bool Delete()
        {
            MyCommand = MyCommandBuilder("delete from AddressType where id = @id");

            MyCommand.Parameters.AddWithValue("@id", Id);

            return ExecuteNonQuery(MyCommand);
        }

        public bool SelectById()
        {
            MyCommand = MyCommandBuilder("select id, name, description from AddressType where id = @id");

            MyCommand.Parameters.AddWithValue("@id", Id);


            MyReader = MyCommand.ExecuteReader();

            while(MyReader.Read())
            {
                Name = MyReader["name"].ToString();
                Description = MyReader["description"].ToString();
                return true;
            }
            return false;
        }

        public System.Data.DataSet Select()
        {
            MyCommand = MyCommandBuilder("Select id, name, description from AddressType");
            return ExecuteDataSet(MyCommand);
        }


    }
}
