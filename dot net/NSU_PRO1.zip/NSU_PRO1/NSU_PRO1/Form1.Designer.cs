﻿namespace NSU_PRO1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.backupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.loginHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.referencesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.countryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.addressTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.personToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.designationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.documentTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fingerPrintTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.educationGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maritalStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.professionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.retinaTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relativeTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.religionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.titleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instituteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.officeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.personToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.personToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.addressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.educationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maritalStatusToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.professionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.retinaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relativeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.religioNToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.socialMediaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.professionToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.dashBoardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.userToolStripMenuItem,
            this.referencesToolStripMenuItem,
            this.personToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(734, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 484);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(734, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(734, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.profileToolStripMenuItem,
            this.toolStripSeparator1,
            this.backupToolStripMenuItem,
            this.restoreToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // profileToolStripMenuItem
            // 
            this.profileToolStripMenuItem.Name = "profileToolStripMenuItem";
            this.profileToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.profileToolStripMenuItem.Text = "&Profile";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // backupToolStripMenuItem
            // 
            this.backupToolStripMenuItem.Name = "backupToolStripMenuItem";
            this.backupToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.backupToolStripMenuItem.Text = "&Backup";
            // 
            // restoreToolStripMenuItem
            // 
            this.restoreToolStripMenuItem.Name = "restoreToolStripMenuItem";
            this.restoreToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.restoreToolStripMenuItem.Text = "&Restore";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(149, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            // 
            // userToolStripMenuItem
            // 
            this.userToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listToolStripMenuItem,
            this.myAccountToolStripMenuItem,
            this.toolStripSeparator3,
            this.loginHistoryToolStripMenuItem});
            this.userToolStripMenuItem.Name = "userToolStripMenuItem";
            this.userToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.userToolStripMenuItem.Text = "&User";
            // 
            // listToolStripMenuItem
            // 
            this.listToolStripMenuItem.Name = "listToolStripMenuItem";
            this.listToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.listToolStripMenuItem.Text = "&List";
            // 
            // myAccountToolStripMenuItem
            // 
            this.myAccountToolStripMenuItem.Name = "myAccountToolStripMenuItem";
            this.myAccountToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.myAccountToolStripMenuItem.Text = "&My Account";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(149, 6);
            // 
            // loginHistoryToolStripMenuItem
            // 
            this.loginHistoryToolStripMenuItem.Name = "loginHistoryToolStripMenuItem";
            this.loginHistoryToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.loginHistoryToolStripMenuItem.Text = "Login &History";
            // 
            // referencesToolStripMenuItem
            // 
            this.referencesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripSeparator4,
            this.personToolStripMenuItem,
            this.toolStripSeparator6,
            this.instituteToolStripMenuItem,
            this.officeToolStripMenuItem,
            this.toolStripSeparator7});
            this.referencesToolStripMenuItem.Name = "referencesToolStripMenuItem";
            this.referencesToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.referencesToolStripMenuItem.Text = "&References";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(149, 6);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.countryToolStripMenuItem,
            this.cityToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripSeparator5,
            this.addressTypeToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem3.Text = "&Address";
            // 
            // countryToolStripMenuItem
            // 
            this.countryToolStripMenuItem.Name = "countryToolStripMenuItem";
            this.countryToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.countryToolStripMenuItem.Text = "&Country";
            // 
            // cityToolStripMenuItem
            // 
            this.cityToolStripMenuItem.Name = "cityToolStripMenuItem";
            this.cityToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cityToolStripMenuItem.Text = "&District";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem1.Text = "&Thana";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem2.Text = "&Village";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(149, 6);
            // 
            // addressTypeToolStripMenuItem
            // 
            this.addressTypeToolStripMenuItem.Name = "addressTypeToolStripMenuItem";
            this.addressTypeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.addressTypeToolStripMenuItem.Text = "Address Type";
            // 
            // personToolStripMenuItem
            // 
            this.personToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.designationToolStripMenuItem,
            this.documentTypeToolStripMenuItem,
            this.educationGroupToolStripMenuItem,
            this.fingerPrintTypeToolStripMenuItem,
            this.imageTypeToolStripMenuItem,
            this.toolStripMenuItem4,
            this.maritalStatusToolStripMenuItem,
            this.toolStripMenuItem5,
            this.professionToolStripMenuItem,
            this.retinaTypeToolStripMenuItem,
            this.relativeTypeToolStripMenuItem,
            this.religionToolStripMenuItem,
            this.titleToolStripMenuItem});
            this.personToolStripMenuItem.Name = "personToolStripMenuItem";
            this.personToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.personToolStripMenuItem.Text = "&Person";
            // 
            // designationToolStripMenuItem
            // 
            this.designationToolStripMenuItem.Name = "designationToolStripMenuItem";
            this.designationToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.designationToolStripMenuItem.Text = "&Designation";
            // 
            // documentTypeToolStripMenuItem
            // 
            this.documentTypeToolStripMenuItem.Name = "documentTypeToolStripMenuItem";
            this.documentTypeToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.documentTypeToolStripMenuItem.Text = "Docume&nt Type";
            // 
            // fingerPrintTypeToolStripMenuItem
            // 
            this.fingerPrintTypeToolStripMenuItem.Name = "fingerPrintTypeToolStripMenuItem";
            this.fingerPrintTypeToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.fingerPrintTypeToolStripMenuItem.Text = "&Finger Print Type";
            // 
            // imageTypeToolStripMenuItem
            // 
            this.imageTypeToolStripMenuItem.Name = "imageTypeToolStripMenuItem";
            this.imageTypeToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.imageTypeToolStripMenuItem.Text = "&Image Type";
            // 
            // educationGroupToolStripMenuItem
            // 
            this.educationGroupToolStripMenuItem.Name = "educationGroupToolStripMenuItem";
            this.educationGroupToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.educationGroupToolStripMenuItem.Text = "&Education Group";
            // 
            // maritalStatusToolStripMenuItem
            // 
            this.maritalStatusToolStripMenuItem.Name = "maritalStatusToolStripMenuItem";
            this.maritalStatusToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.maritalStatusToolStripMenuItem.Text = "&Marital Status";
            // 
            // professionToolStripMenuItem
            // 
            this.professionToolStripMenuItem.Name = "professionToolStripMenuItem";
            this.professionToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.professionToolStripMenuItem.Text = "&Profession";
            // 
            // retinaTypeToolStripMenuItem
            // 
            this.retinaTypeToolStripMenuItem.Name = "retinaTypeToolStripMenuItem";
            this.retinaTypeToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.retinaTypeToolStripMenuItem.Text = "&Retina Type";
            // 
            // relativeTypeToolStripMenuItem
            // 
            this.relativeTypeToolStripMenuItem.Name = "relativeTypeToolStripMenuItem";
            this.relativeTypeToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.relativeTypeToolStripMenuItem.Text = "Relative &Type";
            // 
            // religionToolStripMenuItem
            // 
            this.religionToolStripMenuItem.Name = "religionToolStripMenuItem";
            this.religionToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.religionToolStripMenuItem.Text = "Re&ligion";
            // 
            // titleToolStripMenuItem
            // 
            this.titleToolStripMenuItem.Name = "titleToolStripMenuItem";
            this.titleToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.titleToolStripMenuItem.Text = "&Title";
            // 
            // instituteToolStripMenuItem
            // 
            this.instituteToolStripMenuItem.Name = "instituteToolStripMenuItem";
            this.instituteToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.instituteToolStripMenuItem.Text = "&Institute";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(149, 6);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem4.Text = "Interes&t";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem5.Text = "Medi&a";
            // 
            // officeToolStripMenuItem
            // 
            this.officeToolStripMenuItem.Name = "officeToolStripMenuItem";
            this.officeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.officeToolStripMenuItem.Text = "&Office";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(149, 6);
            // 
            // personToolStripMenuItem1
            // 
            this.personToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.personToolStripMenuItem2,
            this.toolStripSeparator8,
            this.addressToolStripMenuItem,
            this.contactToolStripMenuItem,
            this.educationToolStripMenuItem,
            this.emailToolStripMenuItem,
            this.toolStripMenuItem6,
            this.imageToolStripMenuItem,
            this.interestToolStripMenuItem,
            this.maritalStatusToolStripMenuItem1,
            this.professionToolStripMenuItem1,
            this.retinaToolStripMenuItem,
            this.relativeToolStripMenuItem,
            this.religioNToolStripMenuItem1,
            this.socialMediaToolStripMenuItem,
            this.professionToolStripMenuItem2,
            this.toolStripSeparator9,
            this.dashBoardToolStripMenuItem});
            this.personToolStripMenuItem1.Name = "personToolStripMenuItem1";
            this.personToolStripMenuItem1.Size = new System.Drawing.Size(55, 20);
            this.personToolStripMenuItem1.Text = "&Person";
            // 
            // personToolStripMenuItem2
            // 
            this.personToolStripMenuItem2.Name = "personToolStripMenuItem2";
            this.personToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.personToolStripMenuItem2.Text = "&Person";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(149, 6);
            // 
            // addressToolStripMenuItem
            // 
            this.addressToolStripMenuItem.Name = "addressToolStripMenuItem";
            this.addressToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.addressToolStripMenuItem.Text = "&Address";
            // 
            // contactToolStripMenuItem
            // 
            this.contactToolStripMenuItem.Name = "contactToolStripMenuItem";
            this.contactToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.contactToolStripMenuItem.Text = "&Contact";
            // 
            // educationToolStripMenuItem
            // 
            this.educationToolStripMenuItem.Name = "educationToolStripMenuItem";
            this.educationToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.educationToolStripMenuItem.Text = "&Education";
            // 
            // emailToolStripMenuItem
            // 
            this.emailToolStripMenuItem.Name = "emailToolStripMenuItem";
            this.emailToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.emailToolStripMenuItem.Text = "&Email";
            // 
            // imageToolStripMenuItem
            // 
            this.imageToolStripMenuItem.Name = "imageToolStripMenuItem";
            this.imageToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.imageToolStripMenuItem.Text = "&Image";
            // 
            // interestToolStripMenuItem
            // 
            this.interestToolStripMenuItem.Name = "interestToolStripMenuItem";
            this.interestToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.interestToolStripMenuItem.Text = "Interes&t";
            // 
            // maritalStatusToolStripMenuItem1
            // 
            this.maritalStatusToolStripMenuItem1.Name = "maritalStatusToolStripMenuItem1";
            this.maritalStatusToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.maritalStatusToolStripMenuItem1.Text = "&Marital Status";
            // 
            // professionToolStripMenuItem1
            // 
            this.professionToolStripMenuItem1.Name = "professionToolStripMenuItem1";
            this.professionToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.professionToolStripMenuItem1.Text = "&Profession";
            // 
            // retinaToolStripMenuItem
            // 
            this.retinaToolStripMenuItem.Name = "retinaToolStripMenuItem";
            this.retinaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.retinaToolStripMenuItem.Text = "&Retina";
            // 
            // relativeToolStripMenuItem
            // 
            this.relativeToolStripMenuItem.Name = "relativeToolStripMenuItem";
            this.relativeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.relativeToolStripMenuItem.Text = "Relati&ve";
            // 
            // religioNToolStripMenuItem1
            // 
            this.religioNToolStripMenuItem1.Name = "religioNToolStripMenuItem1";
            this.religioNToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.religioNToolStripMenuItem1.Text = "Religio&n";
            // 
            // socialMediaToolStripMenuItem
            // 
            this.socialMediaToolStripMenuItem.Name = "socialMediaToolStripMenuItem";
            this.socialMediaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.socialMediaToolStripMenuItem.Text = "&Social Media";
            // 
            // professionToolStripMenuItem2
            // 
            this.professionToolStripMenuItem2.Name = "professionToolStripMenuItem2";
            this.professionToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.professionToolStripMenuItem2.Text = "&Profession";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(149, 6);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem6.Text = "&Finger Print";
            // 
            // dashBoardToolStripMenuItem
            // 
            this.dashBoardToolStripMenuItem.Name = "dashBoardToolStripMenuItem";
            this.dashBoardToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dashBoardToolStripMenuItem.Text = "&Dash Board";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 506);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "NSU Tracking System";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem profileToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem backupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem myAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem loginHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem referencesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem countryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem addressTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem personToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem designationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem documentTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem educationGroupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fingerPrintTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imageTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem maritalStatusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem professionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem retinaTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relativeTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem religionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem titleToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem instituteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem officeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem personToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem personToolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem addressToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contactToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem educationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem emailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem imageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maritalStatusToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem professionToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem retinaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relativeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem religioNToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem socialMediaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem professionToolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem dashBoardToolStripMenuItem;
    }
}

