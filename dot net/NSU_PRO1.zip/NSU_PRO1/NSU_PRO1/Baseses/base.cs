﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace NSU_PRO1.Baseses
{
    class MyBase
    {
        string _error;

        public string Error
        {
            get
            {
                return _error;
            }
        }



        #region Connection

        SqlConnection CN = new SqlConnection(NSU_PRO1.Properties.Settings.Default.CN);

        bool Connection()
        {
            if (CN.State == ConnectionState.Open)
                return true;

            try
            {
                CN.Open();
                return true;
            }
            catch(Exception ex)
            {
                _error = ex.Message;
            }

            return false;
        }

        #endregion



        #region Command
        protected SqlCommand MyCommand;

        protected SqlCommand MyCommandBuilder(string SQL)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = CN;
            cmd.CommandText = SQL;
            return cmd;
        }
        #endregion


        protected SqlDataReader MyReader;


        protected bool ExecuteNonQuery(SqlCommand cmd)
        {
            if(Connection())
            {
                try
                {
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch(Exception ex)
                {
                    _error = ex.Message;
                }
            }
            return false;
        }


        protected DataSet ExecuteDataSet(SqlCommand cmd)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            if (Connection())
            {
                da.Fill(ds);
            }
            return ds;
        }


    }
}
